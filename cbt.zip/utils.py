import mongoUtils
from time import gmtime, strftime

def getCurrentTime():
    return strftime("%Y-%m-%d %H:%M:%S", gmtime())

def buildChat(refId, command, resp, time):
    chat = {
        "command" : command,
        "response" : resp,
        "time" : time
    }
    mongoUtils.addConv(refId, chat)

def getStops():
    file = "stops.txt"
    stops = list()
    with open(file,'r') as reader:
         for line in reader:
             stops.append(line.strip().upper())
    return stops

def removeStops(sentence):
    stops = getStops()
    tokens = list()
    for word in sentence.split():
        if word.upper() not in stops:
            tokens.append(word)
    return sorted(tokens)

def processAction(action, command, user, bot_name, chatRef):
    action_result = "Processing Action"
    print(bot_name + ' : '+ action_result)
    buildChat(chatRef.inserted_id, command, action_result, getCurrentTime())





if __name__ == '__main__':
    lst = removeStops('I have a problem with delivery')
    print(lst)
    print(set(lst))
