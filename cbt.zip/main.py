import findResponse
import utils
import mongoUtils

if __name__ == '__main__':
    bot_name = 'BOT'
    command = ''
    action = None
    user = input("Please enter your name : ")
    print("I can talk on below listed modules : ")
    print("PO - (for Purchase Orders)")
    print("SO - (for Sales Orders)")
    print("INV - (for Inventory)")
    topic_context = input("Please enter the context you need to talk ? ")

    conversation = {
        "user" : user,
        "time" : utils.getCurrentTime(),
        "inc" : '',
        "context" : topic_context,
        "conversation" : []
    }
    
    chatRef = mongoUtils.saveChat(conversation)

    print('=' * 80)
    print('Welcome to CHATBOT Session')
    print('=' * 80)
    print('Please enter "WRONG" if you find any answer is wrong \nor the chatbot is not able to respond properly')
    print()
    print('Please type "BYE" or "GOODBYE" or "EXIT"to end chat session')         
    print('=' * 80)
    print(bot_name + ' : Greetings of the day !')
    print(bot_name + ' : How may I assist you ?')
    while True:
        command = input(user + ' : ')
        if command.upper() in ('BYE','GOODBYE', 'GOOD BYE', 'EXIT'):
            break
        if command.upper() == 'WRONG':
            utils.initiateInc()
        else:
            print("Action: " + str(action))
            if action is not None:
                utils.processAction(action, command, user, bot_name, chatRef)
                action = None
            else:    
                resp, action = findResponse.respond(command)
                print(bot_name + ' : '+ resp)
                utils.buildChat(chatRef.inserted_id,command, resp, utils.getCurrentTime())