import mongoUtils
import utils

def respond(query):
    if 'GOOD' in query.upper() and 'MORNING' in query.upper():
        return ('Good Morning !',None)
    if 'GOOD' in query.upper() and ('AFTERNOON' in query.upper() or 'AFTER NOON' in query.upper()):
        return ('Good Afternoon !',None)
    if 'GOOD' in query.upper() and 'MORNING' in query.upper():
        return ('Good Night !',None)    
    if 'HOW ARE YOU' in query.upper() or 'HOW ARE U' in query.upper():
        return ("I'm Fine. Thanks. How are you ?",None)
    if 'BYE' in query.upper() or 'GOOD BYE' in query.upper() or 'GOODBYE' in query.upper():
        return ("Thank You. Bye !",None)

    response = mongoUtils.findKnowledge(query)

    if response is None:
        return ("I am not sure about the question...",None)
    else:
        return ((response['response'],response['followup-action']))
    