from pymongo import MongoClient
import utils

def createClient():
    client = MongoClient('localhost:27017')
    return client

def saveChat(chat):
    client = createClient()
    db = client.chatbot
    try:
        chatRef = db.conversations.insert_one(chat)
        print("Chat saved successfully...")
        return chatRef
    except Exception as e:
        print("Unable to save chat : "+ type(e) + str(e))
        return None

def addConv(refId, chat):
    client = createClient()
    db = client.chatbot
    try:
        db.conversations.update_one(
            {"_id" : refId},
            {"$push" : {"conversation" : chat}}
        )
    except Exception as e:
        print("Error pushing chat : "+type(e)+ " "+ str(e))

def addKnowledge(knowledge):
    client = createClient()
    db = client.chatbot
    try:
        db.knowledge.insert_one(knowledge)
        print("Knowledge added successfully...")
    except Exception as e:
        print("Unable to save chat : "+ type(e) + str(e))

def findKnowledge(query):
    query = query.upper()
    tokens = utils.removeStops(query)
    unique_tokens = list(set(tokens))
    client = createClient()
    db = client.chatbot
    criteria = {"command.question" : query}
    result = db.knowledge.find_one(criteria)
    if result is not None:
        return result
    else:
        criteria = {"command.tokens" : tokens}
        result = db.knowledge.find_one(criteria)
        if result is not None:
            return result
        else:
            criteria = {"command.sets" : unique_tokens}
            result = db.knowledge.find_one(criteria)
            if result is not None:
                return result
    return None    

def trainBot():
    print("Starting Training session...")